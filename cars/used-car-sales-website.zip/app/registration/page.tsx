'use client';

import { useState, useEffect, Suspense } from 'react';
import { Header } from '@/components/header';
import { Footer } from '@/components/footer';
import { useSearchParams } from 'next/navigation';
import { FileText, Upload, CheckCircle, Clock, XCircle } from 'lucide-react';

function RegistrationContent() {
  const [formData, setFormData] = useState({
    sellerName: '',
    carBrand: '',
    carModel: '',
    carYear: new Date().getFullYear(),
    chassisNumber: '',
    plateNumber: '',
    buyerName: '',
    sellerEmail: '',
    buyerEmail: '',
    buyerPhone: '',
    transferDate: new Date().toISOString().split('T')[0],
    buyerAddress: '',
    sellerPhone: '',
    documents: [] as string[],
  });
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState('');
  const [uploadedFiles, setUploadedFiles] = useState<File[]>([]);
  const searchParams = useSearchParams();
  const carId = searchParams.get('carId');

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ 
      ...prev, 
      [name]: name === 'carYear' ? parseInt(value) : value 
    }));
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const files = Array.from(e.target.files);
      setUploadedFiles(prev => [...prev, ...files]);
      setFormData(prev => ({
        ...prev,
        documents: [...prev.documents, ...files.map(f => f.name)]
      }));
    }
  };

  const removeFile = (index: number) => {
    setUploadedFiles(prev => prev.filter((_, i) => i !== index));
    setFormData(prev => ({
      ...prev,
      documents: prev.documents.filter((_, i) => i !== index)
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    setSuccess(false);

    try {
      const response = await fetch('/api/registrations', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData),
      });

      if (response.ok) {
        setSuccess(true);
        setFormData({
          sellerName: '',
          carBrand: '',
          carModel: '',
          carYear: new Date().getFullYear(),
          chassisNumber: '',
          plateNumber: '',
          buyerName: '',
          sellerEmail: '',
          buyerEmail: '',
          buyerPhone: '',
          transferDate: new Date().toISOString().split('T')[0],
          buyerAddress: '',
          sellerPhone: '',
          documents: [],
        });
        setUploadedFiles([]);
        setTimeout(() => setSuccess(false), 5000);
      } else {
        setError('Erreur lors de l\'enregistrement');
      }
    } catch (err) {
      setError('Erreur lors de l\'enregistrement');
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <Header />
      <main className="bg-background">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="flex items-center gap-3 mb-8">
            <FileText className="w-8 h-8 text-primary" />
            <h1 className="text-4xl font-bold text-foreground">Immatriculation de véhicule</h1>
          </div>

          <div className="bg-blue-50 border border-blue-200 text-blue-700 px-4 py-3 rounded-lg mb-8">
            <p className="font-semibold mb-2">Procédure d'immatriculation complète</p>
            <p className="text-sm">
              Remplissez le formulaire complet ci-dessous pour déclarer le transfert de propriété de votre véhicule. 
              Préparez vos documents (certificat de vente, pièces d'identité, etc.) et nos équipes traiteront votre dossier rapidement.
            </p>
          </div>

          <div className="bg-card rounded-lg p-8 border border-border">
            {success && (
              <div className="bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded-lg mb-6 flex gap-3">
                <CheckCircle className="w-5 h-5 flex-shrink-0 mt-0.5" />
                <div>
                  <p className="font-semibold">Immatriculation enregistrée avec succès !</p>
                  <p className="text-sm">Vous recevrez un email de confirmation avec un numéro de dossier bientôt.</p>
                </div>
              </div>
            )}

            {error && (
              <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg mb-6 flex gap-3">
                <XCircle className="w-5 h-5 flex-shrink-0 mt-0.5" />
                <div>{error}</div>
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-8">
              {/* Seller Info */}
              <div>
                <h2 className="text-xl font-bold mb-4 text-foreground">Informations du vendeur</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium mb-2 text-foreground">Nom du vendeur *</label>
                    <input
                      type="text"
                      name="sellerName"
                      value={formData.sellerName}
                      onChange={handleChange}
                      required
                      className="w-full px-4 py-2 border border-border rounded-lg text-foreground bg-background"
                      placeholder="Nom complet"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2 text-foreground">Téléphone du vendeur *</label>
                    <input
                      type="tel"
                      name="sellerPhone"
                      value={formData.sellerPhone}
                      onChange={handleChange}
                      required
                      className="w-full px-4 py-2 border border-border rounded-lg text-foreground bg-background"
                      placeholder="+216 98 123 456"
                    />
                  </div>
                  <div className="md:col-span-2">
                    <label className="block text-sm font-medium mb-2 text-foreground">Email du vendeur *</label>
                    <input
                      type="email"
                      name="sellerEmail"
                      value={formData.sellerEmail}
                      onChange={handleChange}
                      required
                      className="w-full px-4 py-2 border border-border rounded-lg text-foreground bg-background"
                    />
                  </div>
                </div>
              </div>

              {/* Car Info */}
              <div>
                <h2 className="text-xl font-bold mb-4 text-foreground">Informations du véhicule</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium mb-2 text-foreground">Marque *</label>
                    <input
                      type="text"
                      name="carBrand"
                      value={formData.carBrand}
                      onChange={handleChange}
                      required
                      className="w-full px-4 py-2 border border-border rounded-lg text-foreground bg-background"
                      placeholder="Ex: Renault"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2 text-foreground">Modèle *</label>
                    <input
                      type="text"
                      name="carModel"
                      value={formData.carModel}
                      onChange={handleChange}
                      required
                      className="w-full px-4 py-2 border border-border rounded-lg text-foreground bg-background"
                      placeholder="Ex: Clio"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2 text-foreground">Année *</label>
                    <input
                      type="number"
                      name="carYear"
                      value={formData.carYear}
                      onChange={handleChange}
                      required
                      className="w-full px-4 py-2 border border-border rounded-lg text-foreground bg-background"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2 text-foreground">Numéro de châssis (VIN) *</label>
                    <input
                      type="text"
                      name="chassisNumber"
                      value={formData.chassisNumber}
                      onChange={handleChange}
                      required
                      className="w-full px-4 py-2 border border-border rounded-lg text-foreground bg-background"
                      placeholder="VIN"
                    />
                  </div>
                  <div className="md:col-span-2">
                    <label className="block text-sm font-medium mb-2 text-foreground">Numéro d'immatriculation *</label>
                    <input
                      type="text"
                      name="plateNumber"
                      value={formData.plateNumber}
                      onChange={handleChange}
                      required
                      className="w-full px-4 py-2 border border-border rounded-lg text-foreground bg-background"
                      placeholder="Plaque d'immatriculation"
                    />
                  </div>
                </div>
              </div>

              {/* Buyer Info */}
              <div>
                <h2 className="text-xl font-bold mb-4 text-foreground">Informations de l'acheteur</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium mb-2 text-foreground">Nom de l'acheteur *</label>
                    <input
                      type="text"
                      name="buyerName"
                      value={formData.buyerName}
                      onChange={handleChange}
                      required
                      className="w-full px-4 py-2 border border-border rounded-lg text-foreground bg-background"
                      placeholder="Nom complet"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2 text-foreground">Téléphone de l'acheteur *</label>
                    <input
                      type="tel"
                      name="buyerPhone"
                      value={formData.buyerPhone}
                      onChange={handleChange}
                      required
                      className="w-full px-4 py-2 border border-border rounded-lg text-foreground bg-background"
                      placeholder="+216 98 234 567"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2 text-foreground">Email de l'acheteur *</label>
                    <input
                      type="email"
                      name="buyerEmail"
                      value={formData.buyerEmail}
                      onChange={handleChange}
                      required
                      className="w-full px-4 py-2 border border-border rounded-lg text-foreground bg-background"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2 text-foreground">Date de transfert *</label>
                    <input
                      type="date"
                      name="transferDate"
                      value={formData.transferDate}
                      onChange={handleChange}
                      required
                      className="w-full px-4 py-2 border border-border rounded-lg text-foreground bg-background"
                    />
                  </div>
                  <div className="md:col-span-2">
                    <label className="block text-sm font-medium mb-2 text-foreground">Adresse de l'acheteur *</label>
                    <input
                      type="text"
                      name="buyerAddress"
                      value={formData.buyerAddress}
                      onChange={handleChange}
                      required
                      className="w-full px-4 py-2 border border-border rounded-lg text-foreground bg-background"
                      placeholder="Adresse complète"
                    />
                  </div>
                </div>
              </div>

              {/* Documents Upload */}
              <div>
                <h2 className="text-xl font-bold mb-4 text-foreground">Documents nécessaires</h2>
                <div className="border-2 border-dashed border-border rounded-lg p-6 text-center mb-4">
                  <Upload className="w-8 h-8 text-muted-foreground mx-auto mb-2" />
                  <label className="cursor-pointer">
                    <p className="text-sm font-medium text-foreground mb-1">Cliquez pour uploader des documents</p>
                    <p className="text-xs text-muted-foreground mb-3">Certificat de vente, pièces d'identité, etc.</p>
                    <input
                      type="file"
                      multiple
                      onChange={handleFileChange}
                      className="hidden"
                      accept=".pdf,.jpg,.jpeg,.png,.doc,.docx"
                    />
                  </label>
                </div>

                {uploadedFiles.length > 0 && (
                  <div className="space-y-2">
                    <p className="text-sm font-medium text-foreground">Fichiers uploadés ({uploadedFiles.length}):</p>
                    {uploadedFiles.map((file, idx) => (
                      <div key={idx} className="flex justify-between items-center bg-background p-3 rounded-lg border border-border">
                        <span className="text-sm text-foreground">{file.name}</span>
                        <button
                          type="button"
                          onClick={() => removeFile(idx)}
                          className="text-red-600 hover:text-red-700 text-xs"
                        >
                          Supprimer
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              <div className="bg-background border border-border rounded-lg p-4">
                <p className="text-sm text-muted-foreground">
                  En soumettant ce formulaire, vous certifiez que toutes les informations fournies sont correctes et complètes. 
                  Un numéro de dossier vous sera envoyé pour suivre votre demande d'immatriculation.
                </p>
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full bg-primary text-primary-foreground py-3 rounded-lg font-bold hover:opacity-90 transition disabled:opacity-50"
              >
                {loading ? 'Enregistrement en cours...' : 'Enregistrer l\'immatriculation'}
              </button>
            </form>
          </div>
        </div>
      </main>
      <Footer />
    </>
  );
}

export default function RegistrationPage() {
  return (
    <Suspense fallback={
      <>
        <Header />
        <div className="min-h-screen bg-background flex items-center justify-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
        </div>
        <Footer />
      </>
    }>
      <RegistrationContent />
    </Suspense>
  );
}
