'use client';

import { useState, useEffect, Suspense } from 'react';
import { Header } from '@/components/header';
import { Footer } from '@/components/footer';
import { CarCard } from '@/components/car-card';
import { Car } from '@/lib/db';
import { useSearchParams } from 'next/navigation';
import { Filter, X } from 'lucide-react';

function CatalogContent() {
  const [cars, setCars] = useState<Car[]>([]);
  const [loading, setLoading] = useState(true);
  const [filtersOpen, setFiltersOpen] = useState(false);
  const [filters, setFilters] = useState({
    brand: '',
    minPrice: '',
    maxPrice: '',
    minYear: '',
    maxYear: '',
    fuelType: '',
    transmission: '',
  });
  const searchParams = useSearchParams();
  const search = searchParams.get('search');

  useEffect(() => {
    const query = new URLSearchParams();
    if (search) query.append('search', search);
    if (filters.brand) query.append('brand', filters.brand);
    if (filters.minPrice) query.append('minPrice', filters.minPrice);
    if (filters.maxPrice) query.append('maxPrice', filters.maxPrice);
    if (filters.minYear) query.append('minYear', filters.minYear);
    if (filters.maxYear) query.append('maxYear', filters.maxYear);
    if (filters.fuelType) query.append('fuelType', filters.fuelType);
    if (filters.transmission) query.append('transmission', filters.transmission);

    fetch(`/api/cars?${query}`)
      .then(res => res.json())
      .then(data => {
        setCars(data);
        setLoading(false);
      })
      .catch(err => {
        console.error('Error fetching cars:', err);
        setLoading(false);
      });
  }, [filters, search]);

  const filterInputClass = "w-full px-4 py-2 border border-border/50 rounded-lg text-foreground bg-background focus:outline-none focus:border-primary focus:ring-2 focus:ring-primary/20 transition-all duration-300";
  const filterLabelClass = "block text-sm font-medium mb-2 text-foreground";

  return (
    <>
      <Header />
      <main className="min-h-screen bg-background">
        <div className="bg-gradient-to-r from-card to-background border-b border-border/50 py-12">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <h1 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-foreground to-primary bg-clip-text text-transparent mb-2">
              Catalogue complet
            </h1>
            <p className="text-muted-foreground">
              Trouvez le véhicule parfait parmi notre sélection
            </p>
          </div>
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
            <div className={`${filtersOpen ? 'block' : 'hidden'} lg:block lg:sticky lg:top-20 h-fit`}>
              <div className="bg-card rounded-xl p-6 border border-border/50 animate-in-up">
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-xl font-bold text-foreground flex items-center gap-2">
                    <Filter className="w-5 h-5 text-primary" />
                    Filtres
                  </h2>
                  <button onClick={() => setFiltersOpen(false)} className="lg:hidden">
                    <X className="w-5 h-5" />
                  </button>
                </div>

                <div className="space-y-5">
                  <div>
                    <label className={filterLabelClass}>Marque</label>
                    <input
                      type="text"
                      placeholder="Ex: Renault"
                      value={filters.brand}
                      onChange={(e) => setFilters({...filters, brand: e.target.value})}
                      className={filterInputClass}
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className={filterLabelClass}>Prix Min (DT)</label>
                      <input
                        type="number"
                        value={filters.minPrice}
                        onChange={(e) => setFilters({...filters, minPrice: e.target.value})}
                        className={filterInputClass}
                      />
                    </div>
                    <div>
                      <label className={filterLabelClass}>Prix Max (DT)</label>
                      <input
                        type="number"
                        value={filters.maxPrice}
                        onChange={(e) => setFilters({...filters, maxPrice: e.target.value})}
                        className={filterInputClass}
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className={filterLabelClass}>Année Min</label>
                      <input
                        type="number"
                        value={filters.minYear}
                        onChange={(e) => setFilters({...filters, minYear: e.target.value})}
                        className={filterInputClass}
                      />
                    </div>
                    <div>
                      <label className={filterLabelClass}>Année Max</label>
                      <input
                        type="number"
                        value={filters.maxYear}
                        onChange={(e) => setFilters({...filters, maxYear: e.target.value})}
                        className={filterInputClass}
                      />
                    </div>
                  </div>

                  <div>
                    <label className={filterLabelClass}>Carburant</label>
                    <select
                      value={filters.fuelType}
                      onChange={(e) => setFilters({...filters, fuelType: e.target.value})}
                      className={filterInputClass}
                    >
                      <option value="">Tous</option>
                      <option value="Essence">Essence</option>
                      <option value="Diesel">Diesel</option>
                      <option value="Hybride">Hybride</option>
                    </select>
                  </div>

                  <div>
                    <label className={filterLabelClass}>Transmission</label>
                    <select
                      value={filters.transmission}
                      onChange={(e) => setFilters({...filters, transmission: e.target.value})}
                      className={filterInputClass}
                    >
                      <option value="">Tous</option>
                      <option value="Manuelle">Manuelle</option>
                      <option value="Automatique">Automatique</option>
                    </select>
                  </div>

                  <button
                    onClick={() => setFilters({
                      brand: '',
                      minPrice: '',
                      maxPrice: '',
                      minYear: '',
                      maxYear: '',
                      fuelType: '',
                      transmission: '',
                    })}
                    className="w-full bg-muted hover:bg-muted/80 text-foreground py-2 rounded-lg transition-all duration-300 font-medium"
                  >
                    Réinitialiser
                  </button>
                </div>
              </div>
            </div>

            <div className="lg:col-span-3">
              <div className="flex justify-between items-center mb-6 lg:hidden">
                <p className="text-muted-foreground font-medium">
                  {cars.length} voiture(s)
                </p>
                <button
                  onClick={() => setFiltersOpen(true)}
                  className="flex items-center gap-2 bg-primary text-primary-foreground px-4 py-2 rounded-lg hover:bg-accent transition-all duration-300"
                >
                  <Filter className="w-4 h-4" />
                  Filtres
                </button>
              </div>

              {loading ? (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {[...Array(6)].map((_, i) => (
                    <div key={i} className="bg-card rounded-xl h-72 animate-pulse border border-border/50" />
                  ))}
                </div>
              ) : cars.length > 0 ? (
                <>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {cars.map((car, idx) => (
                      <div key={car.id} style={{ animationDelay: `${idx * 0.05}s` }} className="animate-in-up">
                        <CarCard car={car} />
                      </div>
                    ))}
                  </div>
                  <p className="mt-8 text-sm text-muted-foreground text-center">
                    {cars.length} véhicule(s) trouvé(s)
                  </p>
                </>
              ) : (
                <div className="text-center py-16 bg-card rounded-xl border border-border/50 animate-in-up">
                  <p className="text-muted-foreground text-lg mb-4">Aucune voiture trouvée</p>
                  <p className="text-sm text-muted-foreground">Essayez de modifier vos critères de recherche</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </>
  );
}

export default function CatalogPage() {
  return (
    <Suspense fallback={
      <>
        <Header />
        <div className="min-h-screen bg-background flex items-center justify-center">
          <div className="flex flex-col items-center gap-4">
            <div className="relative">
              <div className="w-12 h-12 rounded-full border-4 border-border/50 border-t-primary animate-spin" />
            </div>
            <p className="text-muted-foreground">Chargement...</p>
          </div>
        </div>
        <Footer />
      </>
    }>
      <CatalogContent />
    </Suspense>
  );
}
