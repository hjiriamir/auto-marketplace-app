'use client';

import Link from 'next/link';
import Image from 'next/image';
import { Car } from '@/lib/db';
import { Fuel, Gauge, Cog, Heart } from 'lucide-react';
import { useState } from 'react';

interface CarCardProps {
  car: Car;
}

export function CarCard({ car }: CarCardProps) {
  const [isFavorite, setIsFavorite] = useState(false);

  return (
    <Link href={`/car/${car.id}`}>
      <div className="group cursor-pointer h-full">
        <div className="bg-card rounded-xl overflow-hidden border border-border/50 hover:border-primary/50 transition-all duration-500 h-full flex flex-col hover:shadow-lg hover:shadow-primary/20">
          <div className="relative h-56 bg-muted overflow-hidden">
            <Image
              src={car.images[0] || '/placeholder.svg'}
              alt={`${car.brand} ${car.model}`}
              fill
              className="object-cover group-hover:scale-110 transition-transform duration-500"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
            
            <button
              onClick={(e) => {
                e.preventDefault();
                setIsFavorite(!isFavorite);
              }}
              className="absolute top-3 right-3 p-2 bg-black/30 backdrop-blur-sm rounded-full hover:bg-primary/80 transition-all duration-300"
            >
              <Heart
                className={`w-5 h-5 ${isFavorite ? 'fill-primary text-primary' : 'text-white'} transition-colors duration-300`}
              />
            </button>

            <div className="absolute top-3 left-3">
              <span className="inline-block bg-gradient-to-r from-primary to-accent text-primary-foreground text-xs font-bold px-3 py-1 rounded-full">
                {car.condition}
              </span>
            </div>
          </div>

          <div className="p-5 flex flex-col flex-1">
            <h3 className="text-lg font-bold text-foreground mb-1 group-hover:text-primary transition-colors duration-300">
              {car.brand} {car.model}
            </h3>
            <p className="text-sm text-muted-foreground mb-4">{car.year}</p>

            <div className="grid grid-cols-3 gap-3 mb-4 py-3 border-y border-border/30">
              <div className="flex flex-col items-center justify-center">
                <Gauge className="w-4 h-4 text-primary mb-1" />
                <span className="text-xs text-muted-foreground text-center">{(car.mileage / 1000).toFixed(0)}K km</span>
              </div>
              <div className="flex flex-col items-center justify-center">
                <Fuel className="w-4 h-4 text-primary mb-1" />
                <span className="text-xs text-muted-foreground text-center">{car.fuelType}</span>
              </div>
              <div className="flex flex-col items-center justify-center">
                <Cog className="w-4 h-4 text-primary mb-1" />
                <span className="text-xs text-muted-foreground text-center">{car.transmission}</span>
              </div>
            </div>

            <div className="flex justify-between items-center mt-auto">
              <div>
                <p className="text-xs text-muted-foreground">À partir de</p>
                <span className="text-2xl font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
                  {car.price.toLocaleString()} DT
                </span>
              </div>
              <button className="bg-gradient-to-r from-primary to-accent hover:from-accent hover:to-primary text-primary-foreground px-4 py-2 rounded-lg text-sm font-medium transition-all duration-300 transform group-hover:scale-105">
                Voir
              </button>
            </div>
          </div>
        </div>
      </div>
    </Link>
  );
}
