'use client';

import Link from 'next/link';
import { Menu, X, Car, LogOut } from 'lucide-react';
import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { useAuth } from '@/lib/auth-context';

export function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const router = useRouter();
  const { isAuthenticated, logout, username } = useAuth();

  const handleLogout = () => {
    logout();
    router.push('/');
  };

  return (
    <header className="sticky top-0 z-50 bg-card/95 backdrop-blur-lg border-b border-border/50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <Link href="/" className="flex items-center gap-3 group">
            <div className="relative">
              <Car className="w-8 h-8 text-primary group-hover:text-accent transition-colors duration-300" />
              <div className="absolute inset-0 bg-primary/20 rounded-lg blur-lg opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
            </div>
            <span className="text-xl font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">AutoPlus</span>
          </Link>

          <nav className="hidden md:flex items-center gap-1">
            {[
              { href: '/', label: 'Accueil' },
              { href: '/catalog', label: 'Catalogue' },
              { href: '/contact', label: 'Contact' },
              { href: '/registration', label: 'Immatriculation' }
            ].map((item) => (
              <Link
                key={item.href}
                href={item.href}
                className="text-foreground/80 hover:text-primary px-4 py-2 rounded-lg transition-all duration-300 relative group"
              >
                {item.label}
                <div className="absolute inset-0 bg-primary/10 rounded-lg opacity-0 group-hover:opacity-100 transition-opacity duration-300 -z-10" />
                <div className="absolute bottom-0 left-0 w-0 h-0.5 bg-gradient-to-r from-primary to-accent group-hover:w-full transition-all duration-300" />
              </Link>
            ))}
            
            {!isAuthenticated && (
              <Link
                href="/seller"
                className="text-foreground/80 hover:text-primary px-4 py-2 rounded-lg transition-all duration-300 relative group"
              >
                Vendre
                <div className="absolute inset-0 bg-primary/10 rounded-lg opacity-0 group-hover:opacity-100 transition-opacity duration-300 -z-10" />
                <div className="absolute bottom-0 left-0 w-0 h-0.5 bg-gradient-to-r from-primary to-accent group-hover:w-full transition-all duration-300" />
              </Link>
            )}
          </nav>

          <div className="hidden md:flex items-center gap-3">
            {isAuthenticated ? (
              <>
                <span className="text-sm text-muted-foreground px-3 py-2">
                  {username}
                </span>
                <Link
                  href="/admin"
                  className="bg-primary text-primary-foreground px-4 py-2 rounded-lg hover:bg-accent transition-all duration-300 font-medium"
                >
                  Admin
                </Link>
                <button
                  onClick={handleLogout}
                  className="flex items-center gap-2 text-foreground/80 hover:text-primary px-4 py-2 rounded-lg transition-all duration-300"
                >
                  <LogOut className="w-5 h-5" />
                </button>
              </>
            ) : (
              <Link
                href="/login"
                className="bg-primary text-primary-foreground px-4 py-2 rounded-lg hover:bg-accent transition-all duration-300 font-medium"
              >
                Admin
              </Link>
            )}
          </div>

          <button
            className="md:hidden p-2 hover:bg-muted rounded-lg transition-colors duration-300"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

        {isMenuOpen && (
          <nav className="md:hidden pb-4 flex flex-col gap-2 animate-in-up">
            {[
              { href: '/', label: 'Accueil' },
              { href: '/catalog', label: 'Catalogue' },
              { href: '/contact', label: 'Contact' },
              { href: '/registration', label: 'Immatriculation' }
            ].map((item) => (
              <Link
                key={item.href}
                href={item.href}
                className="text-foreground/80 hover:text-primary hover:bg-muted px-4 py-2 rounded-lg transition-all duration-300"
              >
                {item.label}
              </Link>
            ))}
            {!isAuthenticated && (
              <Link
                href="/seller"
                className="text-foreground/80 hover:text-primary hover:bg-muted px-4 py-2 rounded-lg transition-all duration-300"
              >
                Vendre
              </Link>
            )}
            {isAuthenticated ? (
              <>
                <Link
                  href="/admin"
                  className="bg-primary text-primary-foreground px-4 py-2 rounded-lg hover:bg-accent transition-all duration-300 font-medium"
                >
                  Admin
                </Link>
                <button
                  onClick={handleLogout}
                  className="flex items-center gap-2 text-foreground/80 hover:text-primary px-4 py-2 rounded-lg transition-all duration-300"
                >
                  <LogOut className="w-5 h-5" />
                  Déconnexion
                </button>
              </>
            ) : (
              <Link
                href="/login"
                className="bg-primary text-primary-foreground px-4 py-2 rounded-lg hover:bg-accent transition-all duration-300 font-medium"
              >
                Admin
              </Link>
            )}
          </nav>
        )}
      </div>
    </header>
  );
}
