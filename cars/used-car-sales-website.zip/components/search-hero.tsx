'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { Search, ArrowRight } from 'lucide-react';

export function SearchHero() {
  const [search, setSearch] = useState('');
  const router = useRouter();

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (search) {
      router.push(`/catalog?search=${encodeURIComponent(search)}`);
    }
  };

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden bg-gradient-to-b from-card via-background to-background">
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-20 right-10 w-96 h-96 bg-primary/10 rounded-full blur-3xl animate-pulse" />
        <div className="absolute bottom-20 left-10 w-96 h-96 bg-accent/10 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '1s' }} />
      </div>

      <div className="relative z-10 max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center w-full">
        <div className="mb-6 animate-in-up">
          <span className="inline-block bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent text-sm font-bold uppercase tracking-wider mb-4">
            Trouvez votre véhicule idéal
          </span>
          <h1 className="text-5xl md:text-6xl font-bold text-foreground mb-6 leading-tight">
            Découvrez les meilleures <span className="bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">offres automobiles</span>
          </h1>
        </div>

        <p className="text-xl text-muted-foreground mb-12 max-w-2xl mx-auto animate-in-up" style={{ animationDelay: '0.1s' }}>
          Parcourez notre sélection de véhicules d'occasion vérifiés avec prix transparents et procédures simples.
        </p>

        <form onSubmit={handleSearch} className="flex gap-3 max-w-2xl mx-auto mb-12 animate-in-up" style={{ animationDelay: '0.2s' }}>
          <div className="relative flex-1">
            <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 w-5 h-5 text-muted-foreground" />
            <input
              type="text"
              placeholder="Rechercher par marque, modèle..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-12 pr-4 py-4 rounded-xl bg-card border border-border/50 text-foreground placeholder-muted-foreground focus:outline-none focus:border-primary focus:ring-2 focus:ring-primary/20 transition-all duration-300"
            />
          </div>
          <button
            type="submit"
            className="bg-gradient-to-r from-primary to-accent hover:from-accent hover:to-primary text-primary-foreground px-8 py-4 rounded-xl font-semibold transition-all duration-300 flex items-center gap-2 hover:shadow-lg hover:shadow-primary/30"
          >
            <Search className="w-5 h-5" />
            <span className="hidden sm:inline">Chercher</span>
          </button>
        </form>

        <div className="flex justify-center animate-in-up" style={{ animationDelay: '0.3s' }}>
          <a href="#featured" className="flex items-center gap-2 text-primary hover:text-accent transition-colors duration-300">
            <span className="text-sm font-medium">Parcourir les annonces</span>
            <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform duration-300" />
          </a>
        </div>
      </div>
    </section>
  );
}
