'use client';

import { RegistrationRequest } from '@/lib/db';
import { CheckCircle, X } from 'lucide-react';

interface RegistrationsProps {
  registrations: RegistrationRequest[];
  onUpdate: () => void;
}

export function AdminRegistrations({ registrations, onUpdate }: RegistrationsProps) {
  const handleStatusChange = async (id: string, status: 'completed' | 'rejected') => {
    await fetch('/api/registrations', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id, status }),
    });
    onUpdate();
  };

  return (
    <div className="bg-card rounded-lg border border-border overflow-hidden">
      {registrations.length === 0 ? (
        <div className="p-8 text-center">
          <p className="text-muted-foreground">Aucune immatriculation</p>
        </div>
      ) : (
        <div className="divide-y divide-border">
          {registrations.map((reg) => (
            <div key={reg.id} className="p-6 hover:bg-background/50">
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-4">
                <div>
                  <p className="text-xs text-muted-foreground mb-1">Véhicule</p>
                  <p className="font-semibold text-foreground">{reg.carBrand} {reg.carModel}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground mb-1">Vendeur</p>
                  <p className="font-semibold text-foreground">{reg.sellerName}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground mb-1">Acheteur</p>
                  <p className="font-semibold text-foreground">{reg.buyerName}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground mb-1">Statut</p>
                  <span className={`inline-block px-2 py-1 rounded text-xs font-medium ${
                    reg.status === 'pending'
                      ? 'bg-yellow-100 text-yellow-700'
                      : reg.status === 'completed'
                      ? 'bg-green-100 text-green-700'
                      : 'bg-red-100 text-red-700'
                  }`}>
                    {reg.status === 'pending' ? 'En attente' : reg.status === 'completed' ? 'Complété' : 'Rejeté'}
                  </span>
                </div>
              </div>

              {reg.status === 'pending' && (
                <div className="flex gap-2 pt-4 border-t border-border">
                  <button
                    onClick={() => handleStatusChange(reg.id, 'completed')}
                    className="flex items-center gap-2 bg-green-100 text-green-700 px-3 py-1 rounded text-sm hover:bg-green-200 transition"
                  >
                    <CheckCircle className="w-4 h-4" />
                    Accepter
                  </button>
                  <button
                    onClick={() => handleStatusChange(reg.id, 'rejected')}
                    className="flex items-center gap-2 bg-red-100 text-red-700 px-3 py-1 rounded text-sm hover:bg-red-200 transition"
                  >
                    <X className="w-4 h-4" />
                    Rejeter
                  </button>
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
