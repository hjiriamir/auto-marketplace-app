'use client';

import { Car, ContactMessage, RegistrationRequest } from '@/lib/db';
import { BarChart, Bar, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { TrendingUp, Calendar, DollarSign, Users } from 'lucide-react';

interface AdminDashboardProps {
  cars: Car[];
  messages: ContactMessage[];
  registrations: RegistrationRequest[];
}

export function AdminDashboard({ cars, messages, registrations }: AdminDashboardProps) {
  // Calculate stats
  const stats = {
    totalCars: cars.length,
    activeCars: cars.filter(c => c.status === 'active').length,
    soldCars: cars.filter(c => c.status === 'sold').length,
    totalValue: cars.reduce((sum, c) => sum + c.price, 0),
    avgPrice: cars.length > 0 ? Math.round(cars.reduce((sum, c) => sum + c.price, 0) / cars.length) : 0,
    newMessages: messages.length,
    pendingRegistrations: registrations.filter(r => r.status === 'pending').length,
    completedRegistrations: registrations.filter(r => r.status === 'completed').length,
  };

  // Price distribution data
  const priceRanges = [
    { name: '< 10k', count: cars.filter(c => c.price < 10000).length },
    { name: '10k-15k', count: cars.filter(c => c.price >= 10000 && c.price < 15000).length },
    { name: '15k-20k', count: cars.filter(c => c.price >= 15000 && c.price < 20000).length },
    { name: '> 20k', count: cars.filter(c => c.price >= 20000).length },
  ];

  // Fuel type distribution
  const fuelTypes = [
    { name: 'Essence', value: cars.filter(c => c.fuelType === 'Essence').length },
    { name: 'Diesel', value: cars.filter(c => c.fuelType === 'Diesel').length },
    { name: 'Hybride', value: cars.filter(c => c.fuelType === 'Hybride').length },
  ].filter(f => f.value > 0);

  // Status distribution
  const statusData = [
    { name: 'Actif', value: stats.activeCars },
    { name: 'Vendu', value: stats.soldCars },
    { name: 'En attente', value: cars.filter(c => c.status === 'pending').length },
  ];

  const COLORS = ['#22c55e', '#ef4444', '#eab308', '#3b82f6', '#f59e0b'];

  return (
    <div className="space-y-8">
      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-card rounded-lg p-6 border border-border">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground mb-1">Total annonces</p>
              <p className="text-3xl font-bold text-foreground">{stats.totalCars}</p>
            </div>
            <Calendar className="w-8 h-8 text-primary opacity-20" />
          </div>
        </div>

        <div className="bg-card rounded-lg p-6 border border-border">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground mb-1">Valeur totale</p>
              <p className="text-3xl font-bold text-primary">{(stats.totalValue / 1000).toFixed(0)}k DT</p>
            </div>
            <DollarSign className="w-8 h-8 text-accent opacity-20" />
          </div>
        </div>

        <div className="bg-card rounded-lg p-6 border border-border">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground mb-1">Prix moyen</p>
              <p className="text-3xl font-bold text-foreground">{(stats.avgPrice / 1000).toFixed(1)}k DT</p>
            </div>
            <TrendingUp className="w-8 h-8 text-primary opacity-20" />
          </div>
        </div>

        <div className="bg-card rounded-lg p-6 border border-border">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground mb-1">Messages</p>
              <p className="text-3xl font-bold text-foreground">{stats.newMessages}</p>
            </div>
            <Users className="w-8 h-8 text-accent opacity-20" />
          </div>
        </div>
      </div>

      {/* Charts Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Price Distribution */}
        <div className="bg-card rounded-lg p-6 border border-border">
          <h3 className="text-lg font-bold mb-4 text-foreground">Distribution des prix</h3>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={priceRanges}>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--color-border)" />
              <XAxis dataKey="name" stroke="var(--color-muted-foreground)" />
              <YAxis stroke="var(--color-muted-foreground)" />
              <Tooltip 
                contentStyle={{
                  backgroundColor: 'var(--color-card)',
                  border: `1px solid var(--color-border)`,
                  color: 'var(--color-foreground)'
                }}
              />
              <Bar dataKey="count" fill="var(--color-primary)" radius={[8, 8, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Status Distribution */}
        <div className="bg-card rounded-lg p-6 border border-border">
          <h3 className="text-lg font-bold mb-4 text-foreground">État des annonces</h3>
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie
                data={statusData}
                cx="50%"
                cy="50%"
                innerRadius={60}
                outerRadius={100}
                paddingAngle={5}
                dataKey="value"
                label={({ name, value }) => `${name}: ${value}`}
              >
                {statusData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip 
                contentStyle={{
                  backgroundColor: 'var(--color-card)',
                  border: `1px solid var(--color-border)`,
                  color: 'var(--color-foreground)'
                }}
              />
            </PieChart>
          </ResponsiveContainer>
        </div>

        {/* Fuel Type Distribution */}
        <div className="bg-card rounded-lg p-6 border border-border">
          <h3 className="text-lg font-bold mb-4 text-foreground">Types de carburant</h3>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={fuelTypes}>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--color-border)" />
              <XAxis dataKey="name" stroke="var(--color-muted-foreground)" />
              <YAxis stroke="var(--color-muted-foreground)" />
              <Tooltip 
                contentStyle={{
                  backgroundColor: 'var(--color-card)',
                  border: `1px solid var(--color-border)`,
                  color: 'var(--color-foreground)'
                }}
              />
              <Bar dataKey="value" fill="var(--color-accent)" radius={[8, 8, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Registration Stats */}
        <div className="bg-card rounded-lg p-6 border border-border">
          <h3 className="text-lg font-bold mb-4 text-foreground">Immatriculations</h3>
          <div className="space-y-4">
            <div className="flex justify-between items-center pb-4 border-b border-border">
              <span className="text-muted-foreground">En attente</span>
              <span className="text-2xl font-bold text-foreground">{stats.pendingRegistrations}</span>
            </div>
            <div className="flex justify-between items-center pb-4 border-b border-border">
              <span className="text-muted-foreground">Complétées</span>
              <span className="text-2xl font-bold text-primary">{stats.completedRegistrations}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-muted-foreground">Total</span>
              <span className="text-2xl font-bold text-foreground">{registrations.length}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Quick Stats */}
      <div className="bg-card rounded-lg p-6 border border-border">
        <h3 className="text-lg font-bold mb-4 text-foreground">Résumé rapide</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-background rounded-lg p-4">
            <p className="text-sm text-muted-foreground mb-1">Annonces actives</p>
            <p className="text-2xl font-bold text-primary">{stats.activeCars}</p>
            <p className="text-xs text-muted-foreground mt-1">{Math.round((stats.activeCars / stats.totalCars) * 100)}% du total</p>
          </div>
          <div className="bg-background rounded-lg p-4">
            <p className="text-sm text-muted-foreground mb-1">Annonces vendues</p>
            <p className="text-2xl font-bold text-accent">{stats.soldCars}</p>
            <p className="text-xs text-muted-foreground mt-1">{Math.round((stats.soldCars / stats.totalCars) * 100) || 0}% du total</p>
          </div>
          <div className="bg-background rounded-lg p-4">
            <p className="text-sm text-muted-foreground mb-1">Messages non traités</p>
            <p className="text-2xl font-bold text-foreground">{stats.newMessages}</p>
            <p className="text-xs text-muted-foreground mt-1">À traiter</p>
          </div>
        </div>
      </div>
    </div>
  );
}
