'use client';

import { Car } from '@/lib/db';
import { Edit2, Trash2, CheckCircle, Clock } from 'lucide-react';
import { useState } from 'react';

interface CarListProps {
  cars: Car[];
  onUpdate: () => void;
}

export function AdminCarList({ cars, onUpdate }: CarListProps) {
  const [editingId, setEditingId] = useState<string | null>(null);

  const handleDelete = async (id: string) => {
    if (confirm('Êtes-vous sûr ?')) {
      await fetch(`/api/cars/${id}`, { method: 'DELETE' });
      onUpdate();
    }
  };

  const handleStatusChange = async (id: string, status: 'active' | 'sold' | 'pending') => {
    await fetch(`/api/cars/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status }),
    });
    onUpdate();
  };

  return (
    <div className="bg-card rounded-lg border border-border overflow-hidden">
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead className="bg-background border-b border-border">
            <tr>
              <th className="px-6 py-4 text-left text-sm font-semibold text-foreground">Véhicule</th>
              <th className="px-6 py-4 text-left text-sm font-semibold text-foreground">Prix</th>
              <th className="px-6 py-4 text-left text-sm font-semibold text-foreground">Année</th>
              <th className="px-6 py-4 text-left text-sm font-semibold text-foreground">KM</th>
              <th className="px-6 py-4 text-left text-sm font-semibold text-foreground">Statut</th>
              <th className="px-6 py-4 text-left text-sm font-semibold text-foreground">Actions</th>
            </tr>
          </thead>
          <tbody>
            {cars.map((car) => (
              <tr key={car.id} className="border-b border-border hover:bg-background/50">
                <td className="px-6 py-4">
                  <p className="font-semibold text-foreground">{car.brand} {car.model}</p>
                  <p className="text-sm text-muted-foreground">{car.seller.name}</p>
                </td>
                <td className="px-6 py-4 text-foreground font-semibold">{car.price.toLocaleString()} DT</td>
                <td className="px-6 py-4 text-foreground">{car.year}</td>
                <td className="px-6 py-4 text-foreground">{car.mileage.toLocaleString()}</td>
                <td className="px-6 py-4">
                  <select
                    value={car.status}
                    onChange={(e) => handleStatusChange(car.id, e.target.value as any)}
                    className={`px-3 py-1 rounded-lg text-sm font-medium ${
                      car.status === 'active'
                        ? 'bg-green-100 text-green-700'
                        : car.status === 'sold'
                        ? 'bg-gray-100 text-gray-700'
                        : 'bg-yellow-100 text-yellow-700'
                    }`}
                  >
                    <option value="active">Actif</option>
                    <option value="pending">En attente</option>
                    <option value="sold">Vendu</option>
                  </select>
                </td>
                <td className="px-6 py-4">
                  <button
                    onClick={() => handleDelete(car.id)}
                    className="text-red-600 hover:text-red-700 transition"
                  >
                    <Trash2 className="w-5 h-5" />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
