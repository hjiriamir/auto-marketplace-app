'use client';

import { useState } from 'react';
import { X } from 'lucide-react';

interface AddCarProps {
  onSuccess: () => void;
}

export function AdminAddCar({ onSuccess }: AddCarProps) {
  const [formData, setFormData] = useState({
    brand: '',
    model: '',
    year: new Date().getFullYear(),
    price: 0,
    mileage: 0,
    fuelType: 'Essence',
    transmission: 'Manuelle',
    condition: 'Bon',
    description: '',
    seller: {
      name: '',
      phone: '',
      email: '',
    },
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    
    if (name.startsWith('seller.')) {
      const field = name.split('.')[1];
      setFormData(prev => ({
        ...prev,
        seller: { ...prev.seller, [field]: value }
      }));
    } else {
      setFormData(prev => ({
        ...prev,
        [name]: name === 'year' || name === 'price' || name === 'mileage' 
          ? parseInt(value) 
          : value
      }));
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      const response = await fetch('/api/cars', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...formData,
          images: ['/car-for-sale.jpg'],
          status: 'active',
        }),
      });

      if (response.ok) {
        onSuccess();
      } else {
        setError('Erreur lors de l\'ajout de l\'annonce');
      }
    } catch (err) {
      setError('Erreur lors de l\'ajout de l\'annonce');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-card rounded-lg p-6 border border-border mb-6">
      <h2 className="text-xl font-bold mb-4 text-foreground">Nouvelle annonce</h2>

      {error && (
        <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg mb-4">
          {error}
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <input
            type="text"
            name="brand"
            placeholder="Marque"
            value={formData.brand}
            onChange={handleChange}
            required
            className="px-4 py-2 border border-border rounded-lg text-foreground bg-background"
          />
          <input
            type="text"
            name="model"
            placeholder="Modèle"
            value={formData.model}
            onChange={handleChange}
            required
            className="px-4 py-2 border border-border rounded-lg text-foreground bg-background"
          />
          <input
            type="number"
            name="year"
            placeholder="Année"
            value={formData.year}
            onChange={handleChange}
            required
            className="px-4 py-2 border border-border rounded-lg text-foreground bg-background"
          />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <input
            type="number"
            name="price"
            placeholder="Prix (DT)"
            value={formData.price}
            onChange={handleChange}
            required
            className="px-4 py-2 border border-border rounded-lg text-foreground bg-background"
          />
          <input
            type="number"
            name="mileage"
            placeholder="Kilométrage"
            value={formData.mileage}
            onChange={handleChange}
            required
            className="px-4 py-2 border border-border rounded-lg text-foreground bg-background"
          />
          <select
            name="fuelType"
            value={formData.fuelType}
            onChange={handleChange}
            className="px-4 py-2 border border-border rounded-lg text-foreground bg-background"
          >
            <option value="Essence">Essence</option>
            <option value="Diesel">Diesel</option>
            <option value="Hybride">Hybride</option>
          </select>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <select
            name="transmission"
            value={formData.transmission}
            onChange={handleChange}
            className="px-4 py-2 border border-border rounded-lg text-foreground bg-background"
          >
            <option value="Manuelle">Manuelle</option>
            <option value="Automatique">Automatique</option>
          </select>
          <select
            name="condition"
            value={formData.condition}
            onChange={handleChange}
            className="px-4 py-2 border border-border rounded-lg text-foreground bg-background"
          >
            <option value="Excellent">Excellent</option>
            <option value="Bon">Bon</option>
            <option value="Acceptable">Acceptable</option>
          </select>
        </div>

        <textarea
          name="description"
          placeholder="Description"
          value={formData.description}
          onChange={handleChange}
          rows={3}
          className="w-full px-4 py-2 border border-border rounded-lg text-foreground bg-background"
        />

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <input
            type="text"
            name="seller.name"
            placeholder="Nom du vendeur"
            value={formData.seller.name}
            onChange={handleChange}
            required
            className="px-4 py-2 border border-border rounded-lg text-foreground bg-background"
          />
          <input
            type="tel"
            name="seller.phone"
            placeholder="Téléphone"
            value={formData.seller.phone}
            onChange={handleChange}
            required
            className="px-4 py-2 border border-border rounded-lg text-foreground bg-background"
          />
          <input
            type="email"
            name="seller.email"
            placeholder="Email"
            value={formData.seller.email}
            onChange={handleChange}
            required
            className="px-4 py-2 border border-border rounded-lg text-foreground bg-background"
          />
        </div>

        <div className="flex gap-4">
          <button
            type="submit"
            disabled={loading}
            className="bg-primary text-primary-foreground px-6 py-2 rounded-lg font-semibold hover:opacity-90 transition disabled:opacity-50"
          >
            {loading ? 'Ajout en cours...' : 'Ajouter'}
          </button>
        </div>
      </form>
    </div>
  );
}
